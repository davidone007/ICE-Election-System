import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.zeroc.Ice.Communicator;
import com.zeroc.Ice.Util;

import Demo.PrinterPrx;

public class Client {
    public static void main(String[] args) {
        // Lista para almacenar argumentos extra si se necesita
        java.util.List<String> extraArgs = new java.util.ArrayList<>();
        int quantityConsults = 1; // Número de hilos concurrentes
        final double[] accum = { 0.0 }; // Arreglo para acumular tiempos
        String logFile = "./client_logs/consolidated_log.txt";

        // Crear directorio de logs si no existe
        File logDir = new File("./client_logs");
        if (!logDir.exists()) {
            logDir.mkdirs();
        }

        try (Communicator communicator = Util.initialize(args, "config.client", extraArgs)) {
            // Crear el proxy para comunicarse con el servidor
            PrinterPrx service = PrinterPrx.checkedCast(
                    communicator.propertyToProxy("Printer.Proxy"));

            if (service == null) {
                throw new Error("Proxy inválido");
            }

            // Crear un ExecutorService para manejar concurrencia
            ExecutorService executor = Executors.newFixedThreadPool(quantityConsults);
            List<Callable<Void>> tasks = new java.util.ArrayList<>();

            // Crear tareas para ejecutar múltiples consultas
            for (int i = 0; i < quantityConsults; i++) {
                int taskId = i;
                tasks.add(() -> {
                    long startTime = System.nanoTime();
                    // Llamada al servicio remoto
                    String result = service.createVotingBooths(1);
                    long endTime = System.nanoTime();

                    // Calcular tiempo de ejecución en milisegundos
                    double executionTime = (endTime - startTime) / 1_000_000.0;
                    System.out.println(result);

                    // Acumular el tiempo total de ejecución
                    synchronized (accum) {
                        accum[0] += executionTime;
                    }

                    return null; // No se necesita un valor de retorno
                });
            }

            List<Future<Void>> results = executor.invokeAll(tasks); // Ejecutar las tareas

            // Calcular tiempo promedio por tarea
            double averageExecutionTime = accum[0] / quantityConsults;
            System.out.println("Tiempo promedio por consulta: " + averageExecutionTime + " ms");

            // Apagar el ExecutorService
            executor.shutdown();
            communicator.shutdown();
            communicator.waitForShutdown();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
