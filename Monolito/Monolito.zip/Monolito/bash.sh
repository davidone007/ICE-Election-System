#!/bin/bash

# Número de clientes a ejecutar
NUM_CLIENTS=10

# Comando para ejecutar el cliente
CLIENT_COMMAND="java -jar client.jar"

# Archivo de log consolidado
LOG_FILE="./client_logs/consolidated_log.txt"

# Crear el directorio de logs si no existe
mkdir -p "$(dirname "$LOG_FILE")"

# Inicialización de variables
total_time=0
successful_clients=0

# Limpiar log previo si existe
> "$LOG_FILE"

# Función para ejecutar un cliente y capturar el tiempo promedio
execute_client() {
    local client_id=$1

    {
        echo "Iniciando cliente $client_id..."

        # Ejecutar el cliente y capturar salida y errores
        output=$($CLIENT_COMMAND 2>&1)
        status=$?

        if [[ $status -ne 0 ]]; then
            echo "Error en cliente $client_id: $output"
            return
        fi

        # Extraer el tiempo promedio (se espera que sea un número en la salida)
        local time=$(echo "$output" | grep -oE "[0-9]+\.[0-9]+" | head -n 1)

        if [[ -n "$time" ]]; then
            # Convertir el tiempo a milisegundos sin usar bc (manipulación con escala entera)
            local integer_part=${time%%.*} # Parte entera
            local decimal_part=${time#*.} # Parte decimal
            decimal_part=$(printf "%-3s" "$decimal_part" | tr ' ' '0') # Rellenar a 3 dígitos

            # Convertir a milisegundos
            local time_ms=$((integer_part * 1000 + 10#${decimal_part:0:3})) # Convertir decimal seguro
            echo "$time_ms"

            # Actualizar variables compartidas
            total_time=$((total_time + time_ms))
            successful_clients=$((successful_clients + 1))
        else
            echo "No se encontró tiempo promedio para cliente $client_id"
        fi
    } >> "$LOG_FILE" 2>&1
}

# Ejecutar clientes concurrentemente
for i in $(seq 1 $NUM_CLIENTS); do
    execute_client $i &
done

# Esperar a que todos los procesos terminen
wait

# Calcular el promedio final si hubo clientes exitosos
if [[ $successful_clients -gt 0 ]]; then
    average_time=$((total_time / successful_clients))
    echo "Promedio total de tiempo de consulta: $average_time ms" | tee -a "$LOG_FILE"
else
    echo "No hubo clientes exitosos. No se pudo calcular el promedio." | tee -a "$LOG_FILE"
fi

echo "Ejecución completada. Log consolidado en: $LOG_FILE"
