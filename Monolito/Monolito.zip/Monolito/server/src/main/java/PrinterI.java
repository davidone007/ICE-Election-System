import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.zeroc.Ice.Current;

import Demo.CallbackPrx;

//import Demo.Response;

public class PrinterI implements Demo.Printer {

    // -----------------
    @Override
    public void getDocuments(Demo.CallbackPrx callback, Current current) {
        try {
            CiudadanoDao ciudadanoDao = new CiudadanoDao();
            List<String> documents = ciudadanoDao.listarDocumentos();

            // Usa el callback para enviar los documentos al cliente
            callback.reportResponse(String.join(",", documents));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int checkPrimeFactors(int documentId, Current current) {
        try {
            // Verificar si el número es primo directamente
            if (isPrime(documentId)) {
                return 1; // Si es primo, retornar 1.
            }

            // Calcular el número de factores primos únicos
            int primeFactorsCount = countPrimeFactors(documentId);

            // Verificar si el número de factores primos es primo
            return isPrime(primeFactorsCount) ? 1 : 0;
        } catch (Exception e) {
            e.printStackTrace();
            return -1; // En caso de error, retornar -1.
        }
    }

    // Método para contar los factores primos únicos de un número
    private int countPrimeFactors(int number) {
        if (number < 2)
            return 0; // 1 o números menores no tienen factores primos.

        Set<Integer> uniqueFactors = new HashSet<>();
        for (int i = 2; i <= number; i++) {
            while (number % i == 0) {
                uniqueFactors.add(i); // Añadir solo el factor primo único.
                number /= i;
            }
        }
        return uniqueFactors.size();
    }

    // Método para verificar si un número es primo
    public boolean isPrime(int n) {
        if (n <= 1) return false;
        if (n <= 3) return true;
        if (n % 2 == 0 || n % 3 == 0) return false;
        for (int i = 5; i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) return false;
    }
    return true;
}


    // -------------------------------------------------------------------------
    @Override
    public String createVotingBooths(int booths, Current current) {
        String sql = "WITH cte AS (\r\n" + //
                        "    SELECT id FROM ciudadano ORDER BY RANDOM() LIMIT ?\r\n" + //
                        ")\r\n" + //
                        "SELECT documento, mesa_id FROM ciudadano WHERE id IN (SELECT id FROM cte);";
        List<Pair<String, String>> documentoMesaPairs = new ArrayList<>();
        List<String> errors = new ArrayList<>();
        long totalExecutionTime = 0;

        // Consulta a la base de datos
        try (Connection connection = DatabaseConfig.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, booths);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String documento = resultSet.getString("documento");
                    String mesa = resultSet.getString("mesa_id");
                    documentoMesaPairs.add(new Pair<>(documento, mesa));
                }
            }
        } catch (Exception e) {
            return "Error while fetching documents: " + e.getMessage();
        }

        // Aquí ya no usamos hilos, solo retornamos los documentos y mesas
        StringBuilder resultLog = new StringBuilder();
        for (Pair<String, String> pair : documentoMesaPairs) {
            String documento = pair.getKey();
            String mesa = pair.getValue();
            String numeroPrimo = "N/A"; // Inicia con un valor predeterminado

            try {
                int primeFactor = checkPrimeFactors(Integer.parseInt(documento), current);
                if (primeFactor == 1) {
                    numeroPrimo = "Primo";
                } else if (primeFactor == 0) {
                    numeroPrimo = "No Primo";
                }

                // Imprimir la consulta procesada (documento, mesa, número primo)
                resultLog.append("Documento: ").append(documento)
                        .append(", Mesa: ").append(mesa)
                        .append(", Número Primo: ").append(numeroPrimo)
                        .append("\n");

            } catch (Exception e) {
                errors.add("Documento: " + documento + " - Error: " + e.getMessage());
            }
        }

        // Si hay errores, los concatenamos
        if (!errors.isEmpty()) {
            resultLog.append("\nErrores: \n");
            for (String error : errors) {
                resultLog.append(error).append("\n");
            }
        }

        // Devolvemos el log de los resultados
        return resultLog.toString();
    }

    // -------------------- Esto no sirve ------------------------

    // -------------- Aquí gestionamos el menú -----------------
    @Override
    public void message(CallbackPrx proxy, String s, Current current) {
    }

    // Esto pertenecía al anterior patrón de diseño que era el Response
    @Override
    public void printString(String s, Current current) {
        System.out.println("Esto no debe aparecer, es un easter egg ;)");
    }

}
