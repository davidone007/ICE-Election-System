import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CiudadanoDao {

    public List<String> listarDocumentos() throws SQLException {
        String sql = "SELECT documento FROM ciudadano ORDER BY id ASC LIMIT 100";
        List<String> documentos = new ArrayList<>();

        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                documentos.add(resultSet.getString("documento"));
            }
        }
        return documentos;
    }
}
